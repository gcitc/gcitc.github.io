<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <title>지씨아이티</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="지씨아이티, GCIT, MCN, IDC" name="keywords">
  <meta content="지씨아이티" name="description">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.6.3/css/all.css' integrity='sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/' crossorigin='anonymous'>
  <link rel="stylesheet" type="text/css" href="index.css" />  
  <meta property="og:url" content="https://gcit.kr/">
  <meta property="og:image" content="../logo.png"/>
  <meta property="og:title" content="지씨아이티"/>
  <meta property="og:site_name" content="지씨아이티"/>
  <meta property="og:description" content="지씨아이티"/>
  <meta property="og:type" content="website"/>
  <meta name="description" content="지씨아이티"/>
  <meta name="keywords" content="지씨아이티,컴퓨터,호스팅,MCN">
  <link rel="shortcut icon" type="image/x-icon" href="../gc.ico"/>
    <head>
</head>  <body>  <div class='body'>
            <?php
                include "dbcon.php";
                $parts = $_GET['parts'];
                $partsArray = explode(',',$parts);
                foreach($partsArray as $partsNumber){
                    $sql = sprintf("select * from ComputerParts where number = '%d' ;", $partsNumber );
                    $result = mysqli_query($connect, $sql);
                    while($row = mysqli_fetch_array($result)){                    
                        echo "<script>setTimeout(\"Keep('".$row['number']."', '".$row['kind']."', '".$row['name']."', '".$row['price']."')\",1000);</script>";
                    }
                }
            ?>
            <input id='share' type='hidden' />
            <div class='leftContent'>
                <iframe class='leftIFrame' id='leftIFrame' src="./partsPage.php"> </iframe></div>
            <div class='rightContent'>
                <iframe class='rightIFrame' id='rightIFrame' src="./listPage.php"> </iframe> </div>    </div>
        <p align="center">임시 견적 사이트 - <a href="http://shop.danawa.com/virtualestimate/?controller=estimateMain&methods=index&marketPlaceSeq=16&logger_kw=dnw_gnb_esti">클릭</a> - 견적 사이트보다 저렴하게 제공하겠습니다. 구매는 카카오톡 @gcit 로 연락주시길 바랍니다.</p></body>
    <!--jqures.js bootstrap.js 등를 하나로 합침 -->
    <script src="all.js"></script>
</html>