<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <title>지씨아이티</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="지씨아이티, GCIT, MCN, IDC" name="keywords">
  <meta content="지씨아이티" name="description">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">
  <link rel="stylesheet" href="bo.css">
  <meta property="og:url" content="https://gcit.kr/">
  <meta property="og:image" content="../logo.png"/>
  <meta property="og:title" content="지씨아이티"/>
  <meta property="og:site_name" content="지씨아이티"/>
  <meta property="og:description" content="지씨아이티"/>
  <meta property="og:type" content="website"/>
  <meta name="description" content="지씨아이티"/>
  <meta name="keywords" content="지씨아이티,컴퓨터,호스팅,MCN">
  <link rel="shortcut icon" type="image/x-icon" href="../gc.ico"/>
</head><body><h2 align="center">지씨아이티 IDC</h2><br> <br>
  <p align="center">지씨아이티 IDC 서비스 목록</p>
  <p align="center">▶웹 호스팅◀</p>
  <p align="center">▶가상 호스팅◀</p>
  <p align="center">▶클라우드 호스팅◀</p>
  <p align="center">▶서버 호스팅◀</p>
  <p align="center">▶서버 구매◀</p>
  <p align="center">▶코로케이션◀</p>
  <p align="center">▶IDC 부가 서비스◀</p><br>
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-3"><p align="center"><b>웹 호스팅</b></p><br>
        <p align="center">최저 비용으로 간단한 홈페이지 또는 웹사이트 운영에 적합</p> </div>
      <div class="col-lg-3"><p align="center"><b>가상 호스팅</b></p><br>
        <p align="center">저렴한 비용으로 웹 호스팅보다 더 높은 사양이 필요로 하며 관리자권한이 필요로 하시는 분들에게 적합</p></div>
      <div class="col-lg-3"><p align="center"><b>클라우드 호스팅</b></p><br>
        <p align="center">가격 대비 성능이 가장 우수하며 게임 서버와 같은 성능 요구가 높은 작업을 필요로 하시는 분들에게 적합</p></div>
      <div class="col-lg-3"><p align="center"><b>서버 호스팅</b></p><br>
        <p align="center">지씨아이티 서버 전체를 이용하여 각종 모든 작업을 필요로 하시는 분들에게 적합</p></div></div></div>
  <p align="center">서비스 이용 문의 : 카카오톡 @gcit</p></body>
  <!-- jquery.min.js,bootstrap.min.js 하나로 합침 -->
  <script src="all.js"></script></html>