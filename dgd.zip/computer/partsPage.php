<!DOCTYPE html>
        <?php
            include "dbcon.php";
            
            $kind = $_GET['kind'];
            $page = $_GET['page'];
            $short = $_GET['short'];
            $search = $_GET['search'];
            
            if($kind == null){
                $kind = $partsKindsList[0][0];
            }

            if($page == null){
                $page = "1";
            }

            if($short == null){
                $short = $shortWay[0];
            }

            if($search){
                $search = preg_replace ("/[#\&\+\-%@=\/\\\:;,\.'\"\^`~\_|\!\?\*$#<>()\[\]\{\}]/i", "",  $search);
            }else{
                $search = "";
            }
        ?>
    <head>
        <link rel="stylesheet" type="text/css" href="partsPage.css" />
        <script>
            function startFn(){
                document.write("Hello World");
            }
            
            function ReloadParts( kind ){
                location.href = "./partsPage.php?kind=" + kind;
            }

            function Search(){
                kind = '<?=$kind?>';
                location.href = "./partsPage.php?kind=" + kind +"&search=" + document.getElementById('searchArea').value; 
            }

        </script>
    </head>
    <body>
        <div class='top'>
            <div class='searchDiv'>
                <input class='searchArea' id='searchArea' onkeypress="if(event.keyCode==13){Search(); return false;}" type='text'/>
                <span>
                    <img class='searchButton' src='./searchIMG.jpg' onClick='Search()'/>
                </span>
            </div>
            <div>
                <?php
                    if($search){
                        echo "\"".$kind." / ".$search."\" 의 검색 결과";
                    }else{
                        echo "\"".$kind."\" 의 검색 결과";
                    }
                ?>
            </div>
            <div class='short'>
                <?php
                    for($i=0; $i<sizeof($shortWay); $i++){
                        echo "    
                            <div class='shortDT'>
                                <a class='shortText' href='./partsPage.php?kind=".$kind."&page=".$page."&search=".$search."&short=".$shortWay[$i]."'>
                                    $shortWay[$i]
                                </a>
                            </div>
                        ";
                    }
                ?>
            </div>
        </div>
        <?php
            $getValueCheck = false;
            foreach($partsKindsList as $partsList){
                foreach($partsList as $partsName){
                    if($partsName == $kind){
                        $getValueCheck = true;
                        break;
                    }
                }
            }
            
            if($getValueCheck == false){
                echo "<br/>유효하지 않는 요청";
                return;
            }

            $shortCol = "number";
            $shortOrder = "asc";
            switch($short){
                case $shortWay[0]:{
                    $shortCol = "number";
                    $shortOrder = "asc";
                }
                break;
                case $shortWay[1]:{
                    $shortCol = "price";
                    $shortOrder = "asc";
                }
                break;
                case $shortWay[2]:{
                    $shortCol = "price";
                    $shortOrder = "desc";
                }
                break;
                case $shortWay[3]:{
                    $shortCol = "name";
                    $shortOrder = "asc";
                }
                break;
                case $shortWay[4]:{
                    $shortCol = "number";
                    $shortOrder = "desc";
                }
                break;
                default :{
                    echo "<br/>유효하지 않는 요청";
                    return;
                }
            }

            $searchKeyWord = "";
            $search;
            $searchArray = explode(' ', $search);
            foreach($searchArray as $searchWord){
                $searchKeyWord = $searchKeyWord."and (name like '%".$searchWord."%' or explanation like '%".$searchWord."%') ";
            }
            $PageNumber = ((int)$page - 1) * 10;
            $sql = sprintf("select * from ComputerParts where kind = '%s' %s order by %s %s LIMIT %d , 25;", $kind, $searchKeyWord, $shortCol, $shortOrder , $PageNumber );
            $result = mysqli_query($connect, $sql);
            
            if(mysqli_num_rows($result) == 0){
                echo "<br/>상품이 없습니다";
            }
            
            echo "<table>";
            while($row = mysqli_fetch_array($result)){
        ?>
        <tr>
            <td width='80px'>
                <img src="./img/<?=$row['number']?>.jpg" alt="<?=$row['name']?>">
            </td>
            <td>
                <div>
                    <b><?=$row['name']?></b>
                </div>
                <div>
                    <?=$row['explanation']?>
                </div>
            </td>
            <td class='rightData' width='120px'>
                <div class='price'>
                    <span class='price'>
                        <?php
                            if($row['price'] == "0"){
                                echo "판매중지";
                            }else{
                                echo $row['price']."원";
                            }
                        ?>
                    </span>
                </div>
                <a href="#" class='keepButton' onmousedown="parent.window.Keep('<?=$row['number']?>', '<?=$row['kind']?>', '<?=$row['name']?>', '<?=$row['price']?>')">담기</a>
            </td>
        </tr>
        <?php
            }
            echo "</table>";
        ?>
        <div class='pageSelect'>
            <?php
                $startNumber = (int)$page - 5;
                if($startNumber < 1){
                    $startNumber = 1;
                }

                $sql = sprintf("select * from ComputerParts where kind = '%s' %s;", $kind, $searchKeyWord);
                $result = mysqli_query($connect, $sql);    
                $endNumber = mysqli_num_rows($result)/25 + 1;
                for($i = $startNumber; $i< $startNumber + 10 && $i < $endNumber; $i++){
                    if($i == 1 && 1 == (int)$page){
                        echo "<a class='pageNumber pageNumberLeft' href='./partsPage.php?kind=".$kind."&page=".$i."&search=".$search."&short=".$short."'><b>".$i."</b></a>";
                    }else if($i == $startNumber){
                        echo "<a class='pageNumber pageNumberLeft' href='./partsPage.php?kind=".$kind."&page=".$i."&search=".$search."&short=".$short."'>".$i."</a>";
                    }else if($i == (int)$page){
                        echo "<a class='pageNumber' href='./partsPage.php?kind=".$kind."&page=".$i."&search=".$search."&short=".$short."''><b>".$i."</b></a>";
                    }else{
                        echo "<a class='pageNumber' href='./partsPage.php?kind=".$kind."&page=".$i."&search=".$search."&short=".$short."''>".$i."</a>";
                    }
                }
            ?>
        </div>
    </body>
</html>