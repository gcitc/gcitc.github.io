<!DOCTYPE html>
    <head>
        <link rel="stylesheet" type="text/css" href="listPage.css" />
    </head>
    <body>
        <div class='partsList'>
            <?php
                include "dbcon.php";
                for($i=0; $i<3; $i++){
                    $partsKinds = $partsKindsList[$i];
            ?>
                <dt>
                    <span class='titleName'><?=$listName[$i]?></span>
                </dt>
                <?php
                    foreach($partsKinds as $kindsName){
                ?>
                        <dd>
                            <a href="#" class='kindReloadButton' onmousedown="parent.window.ReloadParts('<?=$kindsName?>')"><?=$kindsName?></a>
                            <ul id='<?=$kindsName?>'>
                            </ul>
                        </dd>
                <?php
                    }
                ?>
                <dd class='ddCap'>
                </dd>
            <?php
                }
            ?>
            <dd class='fakeDiv'>
            </dd>
        </div>
        <div class='bottomDiv'>
            <div class='bottomInDiv'>
                <div class='bottomLeft'>
                    총 금액 :
                </div>
                <div class='bottomRight'>
                    <span id='priceSum'>0</span></div>  </div>
            <div class='shareButton'>
                <a onClick='parent.window.share()'> 공유하기</a>   </div></div> </body>
                <script>
function Keep(a,c,d,b){document.getElementById(c).innerHTML+="<li class='partsLi' id='"+a+"'><div class='partsName'>"+d+"</div> <span class='partsPrice'>"+b.toString().replace(/\B(?=(\d{3})+(?!\d))/g,",")+"</span>\uc6d0 <a href='#' class='deleteButton' onmousedown=\"deleteParts('"+a+"')\"> X </a> </li>";document.getElementById("priceSum").innerHTML=(Number(getPrice())+Number(b)).toString().replace(/\B(?=(\d{3})+(?!\d))/g,",")}
function deleteParts(a){price=document.getElementById(a).innerHTML.split('partsPrice">')[1].split("</span>")[0];document.getElementById("priceSum").innerHTML=(Number(getPrice())-Number(price.toString().replace(/,/g,""))).toString().replace(/\B(?=(\d{3})+(?!\d))/g,",");document.getElementById(a).remove();parent.window.Delete(a)}function getPrice(){return document.getElementById("priceSum").innerHTML.toString().replace(/,/g,"")};
        </script></html>