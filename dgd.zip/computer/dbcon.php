<?php
    $db_host = "localhost";   // 호스트네임(IP 값으로도 가능)
    $db_user = "root";  // 사용자 아이디값(root는 최상위 아이디 이며, 데이터베이스마다 별도 설정 가능합니다)
    $db_passwd = "gcitceo0503)%)#";  // 사용자 비밀번호
    $db_name = "computer";  // 사용할 데이터베이스 이름
    $connect = mysqli_connect($db_host,$db_user,$db_passwd) or die ("데이터베이스 연결에 실패하였습니다!");  

    mysqli_select_db($connect, $db_name) or die("mysqli_select_db Error!!! 사용 Database 이름을 확인하세요.");
    mysqli_query($connect,"set NAMES utf8"); 
    
    $partsKindsList = [
        ['CPU','메인보드','메모리','그래픽카드','SSD','하드디스크','케이스','파워','키보드','마우스','사운드/스피커','모니터','쿨러/튜닝','소프트웨어','PC 헤드셋','노트북']];
    $listName = ['컴퓨터'];
    $shortWay = ['등록순', '가격 낮은 순', '가격 높은 순', '이름순', '최신순'];
?> 
